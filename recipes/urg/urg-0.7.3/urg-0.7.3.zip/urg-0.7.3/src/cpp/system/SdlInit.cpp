/*!
  \file
  \brief SDL �V�X�e���̏�����

  \author Satofumi KAMIMURA

  $Id: SdlInit.cpp 453 2009-01-06 12:21:24Z satofumi $
*/

#include <cstdlib>
#include "SdlInit.h"
#include <SDL.h>

using namespace qrk;


struct SdlInit::pImpl
{
  static bool initialized_;
};
bool SdlInit::pImpl::initialized_ = false;


SdlInit::SdlInit(void) : pimpl(new pImpl)
{
  if (pimpl->initialized_) {
    // �������ς݂Ȃ�΁A�߂�
    return;
  }

  if (SDL_Init(0) < 0) {
    // !!! ��O�𓊂���ׂ�
    return;
  }
  atexit(SDL_Quit);
  pimpl->initialized_ = true;
}


SdlInit::~SdlInit(void)
{
}
