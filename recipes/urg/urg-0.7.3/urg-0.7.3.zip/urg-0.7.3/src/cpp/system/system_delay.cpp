/*!
  \file
  \brief �ҋ@�֐�

  \author Satofumi KAMIMURA

  $Id: system_delay.cpp 439 2009-01-03 05:01:55Z satofumi $
*/

#include "system_delay.h"
#include "SdlInit.h"
#include <SDL.h>


namespace
{
  class DelayInit : private qrk::SdlInit
  {
  };
}


void qrk::system_delay(int msec)
{
  // �������p
  static DelayInit sdl_init;

  SDL_Delay(msec);
}
