#ifndef LOCK_H
#define LOCK_H

/*!
  \file
  \brief ���b�N�N���X

  \author Satofumi KAMIMURA

  $Id: Lock.h 439 2009-01-03 05:01:55Z satofumi $
*/

#include "ConditionVariable.h"


namespace qrk
{
  /*!
    \brief ���b�N�N���X
  */
  class Lock {

    friend class ConditionalVariable;
    friend bool ConditionVariable::wait(Lock* lock, int timeout);

    Lock(const Lock& rhs);
    Lock& operator = (const Lock& rhs);

    // !!! ?
    void* operator new (size_t);
    void* operator new[] (size_t);

    struct pImpl;
    const std::auto_ptr<pImpl> pimpl;

  public:
    Lock(void);
    ~Lock(void);


    /*!
      \brief ���b�N
    */
    void lock(void);


    /*!
      \brief �A�����b�N
    */
    void unlock(void);
  };
}

#endif /* !LOCK_GUARD_H */
