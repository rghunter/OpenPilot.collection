#ifndef SYSTEM_GET_TICKS_H
#define SYSTEM_GET_TICKS_H

/*!
  \file
  \brief �^�C���X�^���v�擾�֐�

  \author Satofumi KAMIMURA

  $Id: system_getTicks.h 439 2009-01-03 05:01:55Z satofumi $
*/


namespace qrk
{
  extern int system_getTicks(void);
}

#endif /* !SYSTEM_GET_TICKS_H */
