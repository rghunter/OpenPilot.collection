#ifndef MATH_UTILS_H
#define MATH_UTILS_H

/*!
  \file
  \brief ���w�֐��̕⏕�t�@�C��

  \author Satofumi KAMIMURA

  $Id: MathUtils.h 577 2009-02-15 13:09:14Z satofumi $
*/

#include "DetectOS.h"
#if defined(WINDOWS_OS)
#define _USE_MATH_DEFINES
#endif
#include <cmath>

#if defined(MSC)
extern long lrint(double x);
#endif

#endif /* ! MATH_UTILS_H */
