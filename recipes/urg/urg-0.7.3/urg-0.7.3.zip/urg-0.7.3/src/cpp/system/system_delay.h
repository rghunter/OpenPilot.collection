#ifndef SYSTEM_DELAY_H
#define SYSTEM_DELAY_H

/*!
  \file
  \brief �ҋ@�֐�

  \author Satofumi KAMIMURA

  $Id: system_delay.h 439 2009-01-03 05:01:55Z satofumi $
*/


namespace qrk
{
  extern void system_delay(int msec);
}

#endif /* !SYSTEM_DELAY_H */
