#ifndef IS_USB_COM_H
#define IS_USB_COM_H

/*!
  \file
  \brief Check whether port is Usb or not

  \author Satofumi KAMIMURA

  $Id: IsUsbCom.h 527 2009-01-30 11:32:22Z satofumi $
*/

#include <vector>
#include <string>


namespace qrk
{
  /*!
    \brief class to distinguish Usb port
  */
  class IsUsbCom {
  public:
    virtual ~IsUsbCom(void) {
    }


    virtual std::vector<std::string> setBaseNames(void)
    {
      std::vector<std::string> dummy;
      return dummy;
    }


    /*!
      \brief Checks whether USB of URG is connected to specified port and return the result.

      \param[in] com_port COM port to be examined.

      \retval true If specified port is USB connection's URG port
      \retval false If specified port is not USB connection's URG port.

      \attention Returns false if environment is not Windows
      \attention Tested only in Windows XP. Not tested on other OS
    */
    virtual bool isUsbCom(const char* com_port) = 0;
  };
}

#endif /* !IS_USB_COM_H */
