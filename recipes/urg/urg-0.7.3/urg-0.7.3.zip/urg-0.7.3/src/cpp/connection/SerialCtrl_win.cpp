/*!
  \file
  \brief Processing of serial communications (Windows)

  \author Satofumi KAMIMURA

  $Id: SerialCtrl_win.cpp 565 2009-02-09 05:45:14Z satofumi $

  \todo No need to set the timeout again, if the value of new timeout and previous timeout are same.
  
*/

#include "RingBuffer.h"
#include "DetectOS.h"
#include "delay.h"
#include <windows.h>
#include <string>

#ifdef MSC
#define snprintf _snprintf
#endif

#undef min
#undef max


class RawSerialCtrl
{
  string error_message_;
  HANDLE hCom_;
  int readable_size_;
  int current_timeout_;


public:
  RawSerialCtrl(void)
    : error_message_("no error."), hCom_(INVALID_HANDLE_VALUE),
      readable_size_(0), current_timeout_(0)
  {
  }


  const char* what(void)
  {
    return error_message_.c_str();
  }


  bool connect(const char* device, long baudrate)
  {
    /* Open COM port */
    enum { NameLength = 11 };
    char adjusted_device[NameLength];
    snprintf(adjusted_device, NameLength, "\\\\.\\%s", device);
    hCom_ = CreateFileA(adjusted_device, GENERIC_READ | GENERIC_WRITE, 0,
                        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hCom_ == INVALID_HANDLE_VALUE) {
      error_message_ = string("open failed: ") + device;
      return false;
    }

    // Update communication size
    SetupComm(hCom_, 4096 * 4, 4096);

    // Change baudrate
    bool ret = setBaudrate(baudrate);
    if (! ret) {
      error_message_ = "fail SerialCtrl::setBaudrate()";
    }
    return true;
  }


  void disconnect(void)
  {
    if (hCom_ != INVALID_HANDLE_VALUE) {
      CloseHandle(hCom_);
      hCom_ = INVALID_HANDLE_VALUE;
    }
  }


  bool isConnected(void)
  {
    return (hCom_ == INVALID_HANDLE_VALUE) ? false : true;
  }


  bool setBaudrate(long baudrate)
  {
    long baudrate_value;
    switch (baudrate) {

    case 4800:
      baudrate_value = CBR_4800;
      break;

    case 9600:
      baudrate_value = CBR_9600;
      break;

    case 19200:
      baudrate_value = CBR_19200;
      break;

    case 38400:
      baudrate_value = CBR_38400;
      break;

    case 57600:
      baudrate_value = CBR_57600;
      break;

    case 115200:
      baudrate_value = CBR_115200;
      break;

    default:
      baudrate_value = baudrate;
    }

    DCB dcb;
    GetCommState(hCom_, &dcb);
    dcb.BaudRate = baudrate_value;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.fParity = FALSE;
    dcb.StopBits = ONESTOPBIT;
    if (SetCommState(hCom_, &dcb) == 0) {
      return false;
    } else {
      return true;
    }
  }


  int send(const char* data, int count)
  {
    DWORD n;
    WriteFile(hCom_, data, (DWORD)count, &n, NULL);
    return n;
  }


  int recv(char data[], int count, int timeout,
	   RingBuffer<char>& ring_buffer)
  {
    if (count > readable_size_) {
      // If receiption of required data size is possible then read the data and return
      DWORD dwErrors;
      COMSTAT ComStat;
      ClearCommError(hCom_, &dwErrors, &ComStat);
      readable_size_ = ComStat.cbInQue;
    }

    if (count > readable_size_) {
      COMMTIMEOUTS pcto;
      int each_timeout = 10;

      if (timeout == 0) {
        // Read only existing data and return
        count = readable_size_;

      } else {
        if (timeout < 0) {
          // If timeout value is zero, then timeout dont work,
		  // instead continue to wait untill data is received 
			timeout = 0;
          each_timeout = 0;
        }

        // Set time out
		if (timeout != current_timeout_) {
          GetCommTimeouts(hCom_, &pcto);
          pcto.ReadIntervalTimeout = timeout;
          pcto.ReadTotalTimeoutMultiplier = each_timeout;
          pcto.ReadTotalTimeoutConstant = timeout;
          SetCommTimeouts(hCom_, &pcto);
          current_timeout_ = timeout;
        }
        // Stimulate thread switching.
        delay(1);
      }
    }

    DWORD filled;
    if (count > 0) {
      ReadFile(hCom_, data, (DWORD)count, &filled, NULL);
      if (filled > 0) {
	readable_size_ -= filled;
      }
    }

    int left_size = readable_size_ - count;
    if (left_size > 0) {
      enum { BufferSize = 4096 };
      char buffer[BufferSize];
      DWORD n;
      int read_size = std::min(left_size, static_cast<int>(BufferSize));
      ReadFile(hCom_, buffer, (DWORD)read_size, &n, NULL);
      if (n > 0) {
        ring_buffer.put(buffer, n);
	readable_size_ -= n;
      }
    }
    return filled;
  }


  void flush(void)
  {
    // 
  }
};
