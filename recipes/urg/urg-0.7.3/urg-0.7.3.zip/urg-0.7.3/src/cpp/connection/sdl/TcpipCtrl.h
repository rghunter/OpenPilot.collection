#ifndef TCPIP_CTRL_H
#define TCPIP_CTRL_H

/*!
  \file
  \brief TCP/IP �ʐM

  \author Satofumi KAMIMURA

  $Id: TcpipCtrl.h 225 2008-09-20 10:42:10Z satofumi $
*/

#include "Connection.h"
#include <SDL_net.h>
#include <memory>


namespace qrk
{
  class SocketSet;

  /*!
    \brief TCP/IP �ʐM
  */
  class TcpipCtrl : public Connection
  {
    friend class TcpipServer;

    TcpipCtrl(const TcpipCtrl& rhs);
    TcpipCtrl& operator = (const TcpipCtrl& rhs);

    struct pImpl;
    const std::auto_ptr<pImpl> pimpl;

  public:
    TcpipCtrl(void);
    TcpipCtrl(TCPsocket socket);
    TcpipCtrl(SocketSet* socket_set, TCPsocket socket = NULL);
    ~TcpipCtrl(void);

    const char* what(void);

    bool connect(const char* host, long port);
    void disconnect(void);
    bool setBaudrate(long baudrate);
    long baudrate(void);
    bool isConnected(void);
    int send(const char* data, size_t count);
    int recv(char* data, size_t count, int timeout);
    size_t size(void);
    void flush(void);
    void clear(void);
    void ungetc(const char ch);
  };
}

#endif /* !TCPIP_CTRL_H */
