/*!
  \file
  \brief Supplementary function that uses ConnectionInterface

  \author Satofumi KAMIMURA

  $Id: ConnectionUtils.cpp 509 2009-01-23 20:52:17Z satofumi $
*/

#include "ConnectionUtils.h"
#include "Connection.h"

using namespace qrk;


bool qrk::isLF(const char ch)
{
  return ((ch == '\r') || (ch == '\n')) ? true : false;
}


void qrk::skip(Connection* con, int total_timeout, int each_timeout)
{
  if (each_timeout <= 0) {
    each_timeout = total_timeout;
  }

  char recv_ch;
  while (1) {
    int n = con->recv(&recv_ch, 1, each_timeout);
    if (n <= 0) {
      break;
    }
  }
}


int qrk::readline(Connection* con, char* buf, const size_t count,
                  const int timeout)
{
  // Read and evaluate one by one character
  bool is_timeout = false;
  size_t filled = 0;
  while (filled < count) {
    char recv_ch;
    int n = con->recv(&recv_ch, 1, timeout);
    if (n <= 0) {
      is_timeout = true;
      break;
    } else if (isLF(recv_ch)) {
      break;
    }
    buf[filled++] = recv_ch;
  }
  if (filled == count) {
    con->ungetc(buf[filled -1]);
    buf[filled -1] = '\0';
  } else {
    buf[filled] = '\0';
  }

  if ((filled == 0) && is_timeout) {
    return -1;
  } else {
    return static_cast<int>(filled);
  }
}
