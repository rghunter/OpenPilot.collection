#ifndef CONNECTION_H
#define CONNECTION_H

/*!
  \file
  \brief Communication interface

  \author Satofumi KAMIMURA

  $Id: Connection.h 453 2009-01-06 12:21:24Z satofumi $
*/

#include <cstddef>


namespace qrk
{
  enum {
    RecvTimeout = -1,
    ErrorLastIndex = -2,
  };

  /*!
    \brief Communication interface
  */
  class Connection
  {
  public:
    virtual ~Connection(void) {}


    /*!
      \brief Return internal status

      \return Character array representing the internal status
    */
    virtual const char* what(void) = 0;


    /*!
      \brief Connection to device

      \param[in] device Connected device name
      \param[in] baudrate Connection baudrate

      \retval true Success
      \retval false Failure
    */
    virtual bool connect(const char* device, long baudrate) = 0;


    /*!
      \brief Disconnect
    */
    virtual void disconnect(void) = 0;


    /*!
      \brief Change the baud rate

      \param[in] baudrate Baud rate

      \retval 0 Normal
      \retval < 0 Error
    */
    virtual bool setBaudrate(long baudrate) = 0;
    virtual long baudrate(void) = 0;


    /*!
      \brief The connection status is returned. 

      \retval true Still Connected
      \retval false Disconnected
    */
    virtual bool isConnected(void) = 0;


    /*!
      \brief Transmission

      \param[in] data Transmission data
      \param[in] count Number of transmission bytes

      \return Number of transmitted bytes
    */
    virtual int send(const char* data, size_t count) = 0;


    /*!
      \brief Reception

      \param[out] data Buffer for reception
      \param[in] count Maximum size of receive buffer
      \param[in] timeout Timeout period [msec]
    */
    virtual int recv(char* data, size_t count, int timeout) = 0;


    /*!
      \brief Returns number of bytes of data that has been recieved

      \return  number of bytes of data that has been recieved
    */
    virtual size_t size(void) = 0;


    /*!
      \brief clears transmitted and received data

    */
    virtual void flush(void) = 0;


    /*!
      \brief The transmission buffer and the data that has been received are cleared. 
    */
    virtual void clear(void) = 0;


    /*!
      \brief pushes the 1 character back onto the buffer

      \param[in] ch pushed back character
    */
    virtual void ungetc(const char ch) = 0;
  };
}

#endif /* !CONNECTION_H */
