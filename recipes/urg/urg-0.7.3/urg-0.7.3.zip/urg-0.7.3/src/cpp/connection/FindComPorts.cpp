/*!
  \file
  \brief get COM port list

  \author Satofumi KAMIMURA

  $Id: FindComPorts.cpp 624 2009-02-27 09:15:28Z satofumi $
*/

#include "FindComPorts.h"
#include "IsUsbCom.h"
#include "DetectOS.h"
#ifdef WINDOWS_OS
#include <windows.h>
#else
#include "findFiles.h"
using namespace boost::xpressive;
#endif

using namespace qrk;
using namespace std;


struct FindComPorts::pImpl
{
  vector<string> base_names_;
  IsUsbCom* is_usb_;


  pImpl(IsUsbCom* is_usb) : is_usb_(is_usb)
  {
  //  Windows will search list of COM from registry information .
  //  Hence, this is setting is apply only for Linux and MacOS.
#ifdef LINUX_OS
    base_names_.push_back("/dev/ttyUSB");
    base_names_.push_back("/dev/usb/ttyUSB");
#else
    // !!! Uncertain
    // !!! There may be some basic method to obtain COM ports
    // !!!base_names_.push_back("unknown");
#endif
  }


  void addBaseName(const char* base_name)
  {
    base_names_.insert(base_names_.begin(), base_name);
  }


  void addBaseNames(void)
  {
    if (! is_usb_) {
      return;
    }

    vector<string> additional_ports = is_usb_->setBaseNames();

    for (vector<string>::iterator it = additional_ports.begin();
         it != additional_ports.end(); ++it) {
      addBaseName(it->c_str());
    }
  }


  void orderByDriver(vector<string>& ports)
  {
    if (! is_usb_) {
      return;
    }
    
	// Searches for COM.Based on the result apply ISUsbCom.If it gets any answer put it at the first position.
    size_t last_index = 0;
    for (vector<string>::iterator it = ports.begin();
         it != ports.end(); ++it) {
      if (is_usb_->isUsbCom(it->c_str())) {
        swap(ports[last_index], *it);
        ++last_index;
      }
    }
  }


  void addFoundPorts(vector<string>& found_ports,
		     const string& port)
  {
    for (vector<string>::iterator it = found_ports.begin();
	 it != found_ports.end(); ++it) {

      if (! port.compare(*it)) {
	return;
      }
    }
    found_ports.push_back(port);
  }
};


FindComPorts::FindComPorts(IsUsbCom* is_usb) : pimpl(new pImpl(is_usb))
{
}


FindComPorts::~FindComPorts(void)
{
}


void FindComPorts::clear(void)
{
  pimpl->base_names_.clear();
}


void FindComPorts::addBaseName(const char* base_name)
{
  pimpl->addBaseName(base_name);
}


vector<string> FindComPorts::baseNames(void)
{
  return pimpl->base_names_;
}


#ifdef WINDOWS_OS
// In case of Windows
vector<string> FindComPorts::find(void)
{
  vector<string> found_ports;
  HKEY hkey;
  if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DEVICEMAP\\SERIALCOMM",
                    0, KEY_READ, &hkey) != ERROR_SUCCESS) {
    return found_ports;
  }
  enum { MaxLength = 255 };
  CHAR device[MaxLength];
  char name[MaxLength];

  DWORD ret = ERROR_SUCCESS;
  for (int i = 0; ret == ERROR_SUCCESS; ++i) {
    DWORD dl = MaxLength, nl = MaxLength;
    ret = RegEnumValueA(hkey, i, device, &dl, NULL, NULL, (BYTE*)name, &nl);
    if (ret == ERROR_SUCCESS) {
      pimpl->addFoundPorts(found_ports, string(name));
    }
  }
  RegCloseKey(hkey);

  pimpl->orderByDriver(found_ports);
  return found_ports;
}

#else
//In case of Linux, Mac
vector<string> FindComPorts::find(void)
{
  vector<string> found_ports;

  pimpl->addBaseNames();

  // It searches in each registered base name for the file name
  for (vector<string>::iterator it = pimpl->base_names_.begin();
       it != pimpl->base_names_.end(); ++it) {

    //  Division of directory name and file name
    const char* path = it->c_str();
    const char* last_slash = strrchr(path, '/') + 1;

    string dir_name = it->substr(0, last_slash - path);
    string file_name = it->substr(last_slash - path, string::npos);

    vector<string> ports;
    findFiles(ports, dir_name.c_str(),
	      sregex::compile("[a-zA-Z]+[0-9]+"));

    size_t n = it->size();
    for (vector<string>::iterator fit = ports.begin();
	 fit != ports.end(); ++fit) {
      if (! fit->compare(0, n, *it)) {
	// Registers if it matches.
	pimpl->addFoundPorts(found_ports, *fit);
      }
    }
  }
  pimpl->orderByDriver(found_ports);

  return found_ports;
}
#endif
