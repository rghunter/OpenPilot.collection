#ifndef CONNECTION_UTILS_H
#define CONNECTION_UTILS_H

/*!
  \file
  \brief Supplementary function that uses ConnectionInterface

  \author Satofumi KAMIMURA

  $Id: ConnectionUtils.h 453 2009-01-06 12:21:24Z satofumi $
*/

#include <cstddef>
#include <algorithm>


/*!
  \brief Quick Robot Develoment Kit.
*/
namespace qrk
{
  class Connection;


  /*!
    \brief The line feed code is returned. 

    \retval true If character is LF or CR.
    \retval false If character is not LF or CR
  */
  extern bool isLF(const char ch);


  /*!
    \brief Receive data is skipped. 

    Connection::clear() �Ƃ́A�^�C���A�E�g���Ԃ��w�肵�ēǂݔ�΂���_���قȂ�

    \param[in,out] con Communication resource
    \param[in] total_timeout Upper bound of timeout [msec]
    \param[in] each_timeout Maximum timeout value allowed between receive data [msec]
  */
  extern void skip(Connection* con, int total_timeout, int each_timeout = 0);


  /*!
    \brief Read one complete line
    
	Adds \\0 to the end of array of characters and returns that array.

    \param[in,out] con Communication resource
    \param[out] buf Receive buffer
    \param[in] count  Maximum size of receive buffer
    \param[in] timeout Time Out [msec]

    \return Number of reception characters (If there is no reception and timeout occurs, then return is -1)
  */
  extern int readline(Connection* con, char* buf, const size_t count,
                      const int timeout);


  /*!
    \brief Exchange of connection objects

    Swap connection object a and connection object b.
  */
  template <class T>
  void swapConnection(T& a, T& b)
  {
    Connection* t = a.connection();
    a.setConnection(b.connection());
    b.setConnection(t);
  }
};

#endif /* !CONNECTION_UTILS_H */
