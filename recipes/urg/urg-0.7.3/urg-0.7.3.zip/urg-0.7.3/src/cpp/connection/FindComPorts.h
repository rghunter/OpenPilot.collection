#ifndef FIND_COM_PORTS_H
#define FIND_COM_PORTS_H

/*!
  \file
  \brief get COM port list

  \author Satofumi KAMIMURA

  $Id: FindComPorts.h 486 2009-01-20 14:19:23Z satofumi $

  \attention Tested only in Windows XP. Not tested on other OS 
*/

#include <string>
#include <vector>
#include <memory>


namespace qrk
{
  class IsUsbCom;

  /*!
    \brief Search for serial ports

    Windows obtain list of COM ports using registry information \n 
    In Linux, MacOS corresponding file name to the given pattern is obtained.
  */
  class FindComPorts
  {
    FindComPorts(const FindComPorts& rhs);
    FindComPorts& operator = (const FindComPorts& rhs);

    struct pImpl;
    std::auto_ptr<pImpl> pimpl;

  public:
    FindComPorts(IsUsbCom* is_usb = NULL);
    ~FindComPorts(void);

    void clear(void);
    void addBaseName(const char* base_name);
    std::vector<std::string> baseNames(void);

    /*!
      \brief Obtain list of COM ports 

      \retval Vector of string containing list of COM
    */
    std::vector<std::string> find(void);
  };
}

#endif /* !FIND_COM_PORTS_H */
