#ifndef IS_USING_COM_DRIVER_H
#define IS_USING_COM_DRIVER_H

/*!
  \file
  \brief Examines whether any application is using the specified driver.

  \author Satofumi KAMIMURA

  $Id: isUsingComDriver.h 439 2009-01-03 05:01:55Z satofumi $
*/

namespace qrk
{
  /*!
    \brief Checks for the existance of the COM port that is used by specified driver  and return the result.

    \param[in] com_port COM-port to be examined
    \param[in] driver_name Driver name to be examined

    \retval true If COM port of specified driver exists
    \retval false If COM port of specified driver doest not exist.

    \attention Returns false if environment is not Windows
    \attention Tested only in Windows XP. Not tested on other OS

  */
  bool isUsingComDriver(const char* com_port, const char* driver_name);
}

#endif /* !IS_USING_COM_DRIVER_H */
