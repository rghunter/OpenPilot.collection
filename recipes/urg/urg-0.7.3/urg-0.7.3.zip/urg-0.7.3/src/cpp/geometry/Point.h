#ifndef QRK_POINT_H
#define QRK_POINT_H

/*!
  \file
  \brief �ʒu�̌^��`

  \author Satofumi KAMIMURA

  $Id: Point.h 866 2009-05-12 13:35:59Z satofumi $
*/

namespace qrk
{
  /*!
    \brief �ʒu�̌^��`
  */
  template <typename T>
  class Point
  {
  public:
    T x;
    T y;


    Point(void) : x(0), y(0)
    {
    }


    Point(T x_, T y_) : x(x_), y(y_)
    {
    }


    Point<T>& operator += (const Point<T>& rhs)
    {
      this->x += rhs.x;
      this->y += rhs.y;

      return *this;
    }


    const Point<T> operator + (const Point<T>& rhs) const
    {
      return Point<T>(*this) += rhs;
    }
  };
}

#endif /* !QRK_POINT_H */
