#ifndef SCIP_HANDLER_H
#define SCIP_HANDLER_H

/*!
  \file
  \brief Process SCIP communication

  \author Satofumi KAMIMURA

  $Id: ScipHandler.h 530 2009-01-30 14:57:15Z satofumi $
*/

#include "CaptureSettings.h"
#include <memory>
#include <vector>
#include <string>


namespace qrk
{
  class Connection;
  class RangeSensorParameter;


  /*!
    \brief Handler to SCIP protocol.
  */
  class ScipHandler
  {
    ScipHandler(const ScipHandler& rhs);
    ScipHandler& operator = (const ScipHandler& rhs);

    struct pImpl;
    std::auto_ptr<pImpl> pimpl;

  public:
    static const bool Off = false;
    static const bool On = true;
    static const bool Force = true;

    ScipHandler(void);
    ~ScipHandler(void);

    const char* what(void) const;

    static long encode(const char* data, size_t size);
    static bool checkSum(char* buffer, int size, char actual_sum);

    void setConnection(Connection* con);
    Connection* connection(void);

    // Match the baudrate and then connect the device.
    bool connect(const char* device, long baudrate);

    int send(const char data[], int size);
    int recv(char data[], int size, int timeout);

    // Read the parameter from URG device.
    bool loadParameter(RangeSensorParameter& parameters);

    bool versionLines(std::vector<std::string>& lines);

    //! Transit to timestamp mode
    bool setRawTimestampMode(bool on);

    bool rawTimestamp(int* timestamp);

    bool setLaserOutput(bool on, bool force = false);

    CaptureType receiveCaptureData(std::vector<long>& data, long* timestamp,
                                   int* remain_times = NULL,
                                   int* total_times = NULL);
  };
}

#endif /* !SCIP_HANDLER_H */
