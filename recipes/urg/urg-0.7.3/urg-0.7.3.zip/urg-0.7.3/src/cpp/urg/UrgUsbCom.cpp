/*!
  \file
  \brief Search for USB connected port

  \author Satofumi KAMIMURA

  $Id: UrgUsbCom.cpp 543 2009-02-03 23:18:10Z satofumi $
*/

#include "UrgUsbCom.h"
#include "DetectOS.h"
#include "isUsingComDriver.h"

using namespace qrk;
using namespace std;


UrgUsbCom::UrgUsbCom(void)
{
}


vector<string> UrgUsbCom::setBaseNames(void)
{
  vector<string> ports;
#if defined(LINUX_OS)
  // In case of Linux
  ports.push_back("/dev/ttyACM");

#elif defined(MAC_OS)
  // In case of MacOS
  ports.push_back("/dev/tty.usbmodem");
#endif
  return ports;
}


bool UrgUsbCom::isUsbCom(const char* com_port)
{
  // Search whether "URG Series USB Device Driver (COMx)" or "URG-X002 USB Device Driver (COMx)" is included  in Value.
  if (isUsingComDriver(com_port, "URG Series USB Device Driver") ||
      isUsingComDriver(com_port, "URG-X002 USB Device Driver")) {
    return true;

  } else {
    return false;
  }
}
