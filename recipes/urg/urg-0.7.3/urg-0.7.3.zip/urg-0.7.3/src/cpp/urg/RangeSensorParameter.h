#ifndef RANGE_SENSOR_PARAMETER_H
#define RANGE_SENSOR_PARAMETER_H

/*!
  \file
  \brief Manage range sensor's parameter

  \author Satofumi KAMIMURA

  $Id: RangeSensorParameter.h 439 2009-01-03 05:01:55Z satofumi $
*/

#include <string>


namespace qrk
{
  /*!
    \brief class to manage range sensor's parameter
  */
  class RangeSensorParameter
  {
  public:
    enum {
      MODL = 0,                 //!< Sensor model information
      DMIN,                     //!< Least possible measurement range [mm]
      DMAX,                     //!< Maximum possible measurement range [mm]
      ARES,                     //!< Angular resolution(Number of partitions in 360 degree) 
      AMIN,                     //!< Least possible measurement direction in terms of angle
      AMAX,                     //!< Maximum possible measurement direction in terms of angle
      AFRT,                     //!< Front direction value
      SCAN,                     //!< Standard angular velocity
    };

    std::string model;          //!< Received MODL information
    long distance_min;          //!< Received DMIN information
    long distance_max;          //!< Received DMAX information
    int area_total;             //!< Received ARES information
    int area_min;               //!< Received AMIN information
    int area_max;               //!< Received AMAX information
    int area_front;             //!< Received AFRT information
    int scan_rpm;               //!< Received SCAN information

    RangeSensorParameter(void)
      : model(""), distance_min(0), distance_max(0), area_total(0),
        area_min(0), area_max(0), area_front(0), scan_rpm(600)
    {
    }
  };
}

#endif /* !RANGE_SENSOR_PARAMETER_H */
