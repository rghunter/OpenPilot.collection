#ifndef CAPTURE_SETTINGS_H
#define CAPTURE_SETTINGS_H

/*!
  \file
  \brief Data acquisition setting

  \author Satofumi KAMIMURA

  $Id: CaptureSettings.h 439 2009-01-03 05:01:55Z satofumi $
*/

/*!
  \brief Quick Robot Development Kit.
*/
namespace qrk
{
  /*!
    \brief Receive data type
  */
  typedef enum {
    TypeUnknown,                //!< Unknown
    QT,                         //!< Stop command is received.
    GD,                         //!< Get Data one by one(Distance represent in 3 byte)
    GS,                         //!< Get Data one by one(Distance represent in 2 byte)
    MD,                         //!< Get data automatically(Distance represent in 3 byte)
    MS,                         //!< Get data automatically(Distance represent in 2 byte)
    ME,                         //!< Response of M command
    Mx_Reply,                   //!< The first response message of Mx command
    InvalidData,                //!< Error in receive data
  } CaptureType;


  /*!
    \brief Data acquisition setting
  */
  class CaptureSettings
  {
  public:
    CaptureType type;           //!< Type of receive data
    int error_code;             //!< Error code
    long timestamp;             //!< Time stamp [msec]
    int capture_first;          //!< Acquisition beginning index
    int capture_last;           //!< Acquisition end index
    int skip_lines;             //!< Number of lines to skip
    int skip_frames;            //!< Data acquisition interval
    int remain_times;           //!< Remaining number of  scans
    int data_byte;              //!< Number of data bytes


    CaptureSettings(void)
      : type(TypeUnknown), error_code(-1), timestamp(-1),
        capture_first(-1), capture_last(-1),
        skip_lines(-1), skip_frames(-1), remain_times(-1), data_byte(-1)
    {
    }
  };
}

#endif /*! CAPTURE_SETTINGS_H */
