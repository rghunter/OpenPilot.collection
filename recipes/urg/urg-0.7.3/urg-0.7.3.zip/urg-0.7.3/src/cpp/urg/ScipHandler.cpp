/*!
  \file
  \brief Process SCIP communication

  \author Satofumi KAMIMURA

  $Id: ScipHandler.cpp 554 2009-02-05 00:25:28Z satofumi $
*/

#include "ScipHandler.h"
#include "RangeSensorParameter.h"
#include "Connection.h"
#include "ConnectionUtils.h"
#include "getTicks.h"
#include "delay.h"
#include "DetectOS.h"
#include "log_printf.h"
#include <cstring>

#ifdef MSC
#define snprintf _snprintf
#endif

using namespace qrk;
using namespace std;


namespace
{
  void clearReceived(vector<long>& data, CaptureType& type,
                     int& line_count, int& timeout,
                     string& remain_string, string& left_packet_data)
  {
    data.clear();
    type = TypeUnknown;
    line_count = 0;
    timeout = 0;
    remain_string.clear();
    left_packet_data.clear();
  }
}


struct ScipHandler::pImpl
{
  enum {
    ContinuousTimeout = 100,
    FirstTimeout = 1000,

    BufferSize = 64 + 1 + 16, // Data length + checksum + Line Feed + reserved for future use.

    ResponseTimeout = -1,
    MismatchResponse = -2,
    SendFail = -3,
    ChecksumFail = -4,
    Scip11Response = -14,
  };

  typedef enum {
    LaserUnknown = 0,
    LaserOn,
    LaserOff,
  } LaserState;

  string error_message_;
  Connection* con_;
  LaserState laser_state_;
  bool mx_capturing_;

  vector<long> intensity_data_;

  bool isPreCommand_QT_;


  pImpl(void)
    : error_message_("no error."), con_(NULL), laser_state_(LaserUnknown),
      mx_capturing_(false), isPreCommand_QT_(false)
  {
  }


  bool connect(const char* device, long baudrate)
  {
    if (! con_->connect(device, baudrate)) {
      error_message_ = con_->what();
      return false;
    }

    long try_baudrates[] = { 115200, 19200, 38400, };
    size_t try_size = sizeof(try_baudrates) / sizeof(try_baudrates[0]);

    // The baud rate to be connected is replaced with the first element of the array.
    for (size_t i = 1; i < try_size; ++i) {
      if (baudrate == try_baudrates[i]) {
        swap(try_baudrates[0], try_baudrates[i]);
        break;
      }
    }

    // Connects with the specified baudrate and tests for the response.
    for (size_t i = 0; i < try_size; ++i) {

      // Change baudrate in host side.
      if (! con_->setBaudrate(try_baudrates[i])) {
        error_message_ = con_->what();
        return false;
      }

      // Read and clear last received packet.
      con_->clear();

      // Raise QT
      int return_code = -1;
      char qt_expected_response[] = { 0, -1 };
      // QT is transmitted without using setLaserOutput() , to use return_code
      if (response(return_code, "QT\r", qt_expected_response)) {
        laser_state_ = LaserOff;
        return changeBothBaudrate(baudrate);

      } else if (return_code == ResponseTimeout) {
        // It is considered that, Communication is not possible because of fault in baud rate
        error_message_ = "baudrate is not detected.";
        continue;

      } else if (return_code == MismatchResponse) {
        // Skips the data reception, assuming MD/MS command is responded.
        skip(con_, ContinuousTimeout);
        return changeBothBaudrate(baudrate);

      } else if (return_code == Scip11Response) {
        // SCIP2.0 is transmitted only for the SCIP1.1 protocol. 
        char scip20_expected_response[] = { 0, -1 };
        if (! response(return_code, "SCIP2.0\r", scip20_expected_response)) {
          error_message_ =
            "SCIP1.1 protocol is not supported. Please update URG firmware.";
          return false;
        }
        return changeBothBaudrate(baudrate);

      } else if (return_code == 0xE) {
        // Considering TM mode, TM2 is issued
        char tm2_expected_response[] = { 0, -1 };
        if (response(return_code, "TM2\r", tm2_expected_response)) {
          laser_state_ = LaserOff;
          return changeBothBaudrate(baudrate);
        }
      }
    }
    return false;
  }


  bool changeBothBaudrate(long baudrate)
  {
    // Considered as success, if current baudrate and new baudrate are same.
    // ���̊֐��́AScipHandler::connect() ���A����Ȍ�łȂ��ƌĂ΂�Ȃ�����
    if (con_->baudrate() == baudrate) {
      return true;
    }

    // The baud rate on the URG side is changed. 
    int pre_ticks = getTicks();
    if (! changeBaudrate(baudrate)) {
      error_message_ = "SS command fail.";
      return false;
    }

    // In case of serial communication, wait for one scan after baudrate is change.
    int reply_msec = getTicks() - pre_ticks;
    delay((reply_msec * 4 / 3) + 10);

    // Change baud rate on host side
    return con_->setBaudrate(baudrate);
  }


  bool changeBaudrate(long baudrate)
  {
    if (! ((baudrate == 19200) || (baudrate == 38400) ||
           (baudrate == 57600) || (baudrate == 115200))) {
      error_message_ = "Invalid baudrate value.";
      return false;
    }

    // SS is transmitted, and the baud rate on the URG side is changed.
    char send_buffer[] = "SSxxxxxx\r";
    snprintf(send_buffer, 10, "SS%06ld\r", baudrate);
    int return_code = -1;
    // !!! ���ɐݒ�Ώۂ̃{�[���[�g�A�̏ꍇ�̖߂�l�� ss_expected... �ɒǉ�����
    char ss_expected_response[] = { 0, 0x3, 0x4, -1 };
    if (! response(return_code, send_buffer, ss_expected_response)) {
      error_message_ = "Baudrate change fail.";
      return false;
    }

    return true;
  }


  bool loadParameter(RangeSensorParameter& parameters)
  {
    // Send PP command and receive data
    int return_code = -1;
    char pp_expected_response[] = { 0, -1 };
    vector<string> lines;
    if (! response(return_code, "PP\r", pp_expected_response, &lines)) {
      error_message_ = "PP fail.";
      return false;
    }

    // Store PP response
    if (lines.size() != 8) {
      error_message_ = "Invalid PP response.";
      return false;
    }

    // !!! Should evalute checksum

    int modl_length =
      static_cast<int>(lines[RangeSensorParameter::MODL].size());
    // Character strings except the first tag and checksum are returned.
    if (modl_length > (5 + 2)) {
      modl_length -= (5 + 2);
    }
    parameters.model = lines[RangeSensorParameter::MODL].substr(5, modl_length);

    parameters.distance_min = substr2int(lines[RangeSensorParameter::DMIN], 5);
    parameters.distance_max = substr2int(lines[RangeSensorParameter::DMAX], 5);
    parameters.area_total = substr2int(lines[RangeSensorParameter::ARES], 5);
    parameters.area_min = substr2int(lines[RangeSensorParameter::AMIN], 5);
    parameters.area_max = substr2int(lines[RangeSensorParameter::AMAX], 5);
    parameters.area_front = substr2int(lines[RangeSensorParameter::AFRT], 5);
    parameters.scan_rpm = substr2int(lines[RangeSensorParameter::SCAN], 5);

    return true;
  }


  int substr2int(const string& line, int from_n,
                 int length = string::npos)
  {
    return atoi(line.substr(from_n, length).c_str());
  }


  bool response(int& return_code, const char send_command[],
                char expected_response[],
                vector<string>* lines = NULL)
  {
    return_code = -1;
    if (! con_) {
      error_message_ = "no connection.";
      return false;
    }

    size_t send_size = strlen(send_command);
    int actual_send_size = con_->send(send_command, send_size);
    if (strncmp(send_command, "QT\r", send_size)) {
      isPreCommand_QT_ = false;
    }
    if (actual_send_size != static_cast<int>(send_size)) {
      return_code = SendFail;
      return false;
    }

    // Receive echo back
    char buffer[BufferSize];
    int recv_size = readline(con_, buffer, BufferSize, FirstTimeout);
    if (recv_size < 0) {
      error_message_ = "response timeout.";
      return_code = ResponseTimeout;
      return false;
    }

    // �V���A���ڑ��Ń{�[���[�g�ύX����� 0x00 �́A����O�Ƃ���
    if (! ((recv_size == 1) && (buffer[0] == 0x00))) {
      if ((recv_size != static_cast<int>(send_size - 1)) ||
          (strncmp(buffer, send_command, recv_size))) {
        error_message_ = "mismatch response: " + string(buffer);
        return_code = MismatchResponse;
        return false;
      }
    }

    // Receive response
    // !!! Standardize the above process as much as possible
    // !!! After negative value is added to response of SCIP1.1 protocol, it is stored in return_code.
    recv_size = readline(con_, buffer, BufferSize, ContinuousTimeout);
    if (recv_size < 0) {
      // !!! Tie up this process
      error_message_ = "response timeout.";
      return_code = ResponseTimeout;
      return false;
    }
    if (recv_size == 3) {
      
      // If it is 3 characters, then consider as SCIP2.0 and check the checksum
      // !!! Confirmation of checksum
      if (! checkSum(buffer, recv_size - 1, buffer[recv_size - 1])) {
	return_code = ChecksumFail;
	return false;
      }
      buffer[2] = '\0';
      return_code = strtol(buffer, NULL, 16);

    } else if (recv_size == 1) {
      
      // If it is 1 character, then consider as SCIP1.1 and convert to hexadecimal. 
	  //	Then make it negative number and return the value
      buffer[1] = '\0';
      return_code = -strtol(buffer, NULL, 16);
    }

    // Reception of data area
    // Read one line. If read line has only LF consider as an end.
    do {
      recv_size = readline(con_, buffer, BufferSize, ContinuousTimeout);
      if (lines && (recv_size > 0)) {
        lines->push_back(buffer);
      }
    } while (recv_size > 0);

    // !!! Actually make it loop
    // !!! Store the receive data , if pointer is not NULL.

    for (int i = 0; expected_response[i] != -1; ++i) {
      if (return_code == expected_response[i]) {
        return true;
      }
    }
    return false;
  }


  bool setLaserOutput(bool on, bool force)
  {
    if (((on == true) && (laser_state_ == LaserOn)) ||
        ((on == false) && (laser_state_ == LaserOff))) {
      if (! force) {
        // Return if laser output is same as present status.
        // �����ݒ�t���O�� true �̂Ƃ��͖߂炸�ɐݒ���s��
        return true;
      }
    }
    if ((!on) && isPreCommand_QT_) {
      //fprintf(stderr, "continuous QT\n");
      return false;
    }

    if (on) {
      int return_code = -1;
      char expected_response[] = { 0, -1 };
      if (! response(return_code, "BM\r", expected_response)) {
        error_message_ = "BM fail.";
        return false;
      }
      laser_state_ = LaserOn;
      return true;

    } else {
      // "QT"
      if (! mx_capturing_) {
        // In QT to turn it off, it is necessary to wait for the response.
        int return_code = -1;
        char qt_expected_response[] = { 0, -1 };
        if (! response(return_code, "QT\r", qt_expected_response)) {
          return false;
        }
        laser_state_ = LaserOff;
        isPreCommand_QT_ = true;
        return true;

      } else {
        // QT should not wait for the response from MD to interrupt MD.
        // The response is processed in the reception thread. 
        con_->send("QT\r", 3);
        isPreCommand_QT_ = true;
      }

      return true;
    }
  }


  CaptureType receiveCaptureData(vector<long>& data, long* timestamp,
                                 int* remain_times, int* total_times)
  {
    int line_count = 0;
    intensity_data_.clear();
    data.clear();

    string remain_string;

    CaptureSettings settings;
    string left_packet_data;
    char buffer[BufferSize];

    error_message_ = "no response.";

    // !!! The following process is long. Should divide into functions
    CaptureType type = TypeUnknown;
    int timeout = FirstTimeout;
    int line_size = 0;
    while ((line_size = readline(con_, buffer, BufferSize, timeout)) > 0) {
      //fprintf(stderr, "% 3d: %s\n", line_count, buffer);

      //Confirmation with checksum
      if (line_count != 0) {
        if (! checkSum(buffer, line_size - 1, buffer[line_size - 1])) {
          log_printf("checksum error: %s\n", buffer);
          // return InvalidData;
          // !!! Return to this package When the packet error of URG is lost

          // !!! Existed packets are skipped.
          error_message_ = "invalid packet.";
          clearReceived(data, type, line_count, timeout,
                        remain_string, left_packet_data);
          continue;
        }
      }

      if (line_count == 0) {

        // Echo back
        string line = buffer;
        if ((! line.compare(0, 2, "GD")) || (! line.compare(0, 2, "GS"))) {
          if (! parseGdEchoback(settings, line)) {
            break;
          }
          type = (line[1] = 'D') ? GD : GS;
          data.reserve(settings.capture_last + 1);
          intensity_data_.reserve(settings.capture_last + 1);

        } else if ((! line.compare(0, 2, "MD")) ||
                   (! line.compare(0, 2, "MS"))) {
          if (! parseMdEchoback(settings, line)) {
            break;
          }
          type = (line[1] = 'D') ? MD : MS;
          laser_state_ = LaserOn;
          data.reserve(settings.capture_last + 1);
          intensity_data_.reserve(settings.capture_last + 1);

        } else if (! line.compare(0, 2, "ME")) {
          if (! parseMeEchoback(settings, line)) {
            break;
          }
          type = ME;
          laser_state_ = LaserOn;
          data.reserve(settings.capture_last + 1);
          intensity_data_.reserve(settings.capture_last + 1);

        } else if (! line.compare(0, 2, "QT")) {
          settings.remain_times = 0;
          laser_state_ = LaserOff;
          mx_capturing_ = false;

        } else {
          //return InvalidData;
          // !!! Return to this package When URG is ready to return the normal packet.

          clearReceived(data, type, line_count, timeout,
                        remain_string, left_packet_data);
          //fprintf(stderr, "invalid data: %s\n", buffer);
          continue;
        }

      } else if (line_count == 1) {
        // Response code
        // !!! It is necessary to check whether length is 2 + 1 or not
        buffer[2] = '\0';
        settings.error_code = atoi(buffer);

        // !!! should compare with "OOP"
        if ((settings.error_code == 0) &&
            ((type == MD) || (type == MS) || (type == ME))) {
          if (total_times) {
            *total_times = settings.remain_times;
          }
          type = Mx_Reply;
        }

      } else if (line_count == 2) {
        // Time stamp
        if (timestamp) {
          *timestamp = encode(buffer, 4);
        }
      } else {
        if (line_count == 3) {
          
          // If there is no receive data fill the buffer with dummy value.
          for (int i = 0; i < settings.capture_first; ++i) {
            data.push_back(0);
            intensity_data_.push_back(0);
          }
        }
        // Distance data
        left_packet_data =
          addLengthData(data, string(buffer),
                        left_packet_data, settings.data_byte,
                        settings.skip_lines);
      }
      ++line_count;
      timeout = ContinuousTimeout;
    }

    // !!! type �������f�[�^�擾�̂Ƃ��́A����Ɏ�M�������������A���m�F���ׂ�

    if (remain_times) {
      *remain_times = settings.remain_times;
    }
    return type;
  }


  bool parseGdEchoback(CaptureSettings& settings, const string& line)
  {
    if (line.size() != 12) {
      error_message_ = "Invalid Gx packet has arrived.";
      return false;
    }

    settings.capture_first = substr2int(line, 2, 4);
    settings.capture_last = substr2int(line, 6, 4);
    int skip_lines = substr2int(line, 10, 2);
    settings.skip_lines = (skip_lines == 0) ? 1 : skip_lines;
    settings.data_byte = (line[1] == 'D') ? 3 : 2;

    return true;
  }


  bool parseMdEchoback(CaptureSettings& settings, const string& line)
  {
    if (line.size() != 15) {
      error_message_ = "Invalid Mx packet has arrived.";
      return false;
    }

    settings.capture_first = substr2int(line, 2, 4);
    settings.capture_last = substr2int(line, 6, 4);
    int skip_lines = substr2int(line, 10, 2);
    settings.skip_lines = (skip_lines == 0) ? 1 : skip_lines;
    settings.skip_frames = substr2int(line, 12, 1);
    settings.remain_times = substr2int(line, 13, 2);
    settings.data_byte = (line[1] == 'D') ? 3 : 2;

    if (settings.remain_times == 1) {
      // Laser is turned off after the last data is acquired.
      // In reality, Laser is turned off only after the next set of data is acquired.
      // 1 �Ŕ��肷��ƁA�擾�񐔂� 1 �̂Ƃ��ɂ�����ɓ��삷��
      mx_capturing_ = false;

    } else if (settings.remain_times > 0) {
      mx_capturing_ = true;
    }

    return true;
  }


  bool parseMeEchoback(CaptureSettings& settings, const string& line)
  {
    if (line.size() != 15) {
      error_message_ = "Invalid ME packet has arrived.";
      return false;
    }

    settings.capture_first = substr2int(line, 2, 4);
    settings.capture_last = substr2int(line, 6, 4);
    int skip_lines = substr2int(line, 10, 2);
    settings.skip_lines = (skip_lines == 0) ? 1 : skip_lines;
    settings.skip_frames = substr2int(line, 12, 1);
    settings.remain_times = substr2int(line, 13, 2);
    settings.data_byte = 3;

    if (settings.remain_times == 1) {
      mx_capturing_ = false;

    } else {
      mx_capturing_ = true;
    }

    return true;
  }


  string addLengthData(vector<long>& data,
                       const string& line,
                       const string& left_packet_data,
                       const size_t data_byte, const int skip_lines = 1)
  {
    if (line.empty()) {
      // Return if empty
      return left_packet_data;
    }

    // Fraction�BThe part which will be processed next turn.
    string left_byte = left_packet_data;

    size_t data_size = (left_byte.size() + (line.size() - 1)) / data_byte;
    size_t n = data_size * data_byte - left_byte.size();
    for (size_t i = 0; i < n; ++i) {
      left_byte.push_back(line[i]);
      if (left_byte.size() >= data_byte) {
        // Convert data into distance and store
        long length = encode(&left_byte[0], data_byte);
        for (int j = 0; j < skip_lines; ++j) {
          data.push_back(length);
        }
        left_byte.clear();
      }
    }
    left_byte += line.substr(n, (line.size() - n) - 1);

    return left_byte;
  }
};


ScipHandler::ScipHandler(void) : pimpl(new pImpl)
{
}


ScipHandler::~ScipHandler(void)
{
}


const char* ScipHandler::what(void) const
{
  return pimpl->error_message_.c_str();
}


long ScipHandler::encode(const char* data, size_t size)
{
  int value = 0;

  for (size_t i = 0; i < size; ++i) {
    value <<= 6;
    value &= ~0x3f;
    value |= data[i] - 0x30;
  }
  return value;
}


bool ScipHandler::checkSum(char* buffer, int size, char actual_sum)
{
  char expected_sum = 0x00;
  for (int i = 0; i < size; ++i) {
    expected_sum += buffer[i];
  }
  expected_sum = (expected_sum & 0x3f) + 0x30;

#if 0
  if (expected_sum != actual_sum) {
    fprintf(stderr, "checksum error!\n");
    for (int i = 0; i < size; ++i) {
      fprintf(stderr, "%c", buffer[i]);
    }
    fprintf(stderr, ", %d\n\n", size);
  }
#endif
  return (expected_sum == actual_sum) ? true : false;
}


void ScipHandler::setConnection(Connection* con)
{
  pimpl->con_ = con;
}


Connection* ScipHandler::connection(void)
{
  return pimpl->con_;
}


bool ScipHandler::connect(const char* device, long baudrate)
{
  return pimpl->connect(device, baudrate);
}


int ScipHandler::send(const char data[], int size)
{
  if (size >= 2) {
    // Judge the status of switch on laser here because, 
	// judging the status of laser before receiving the response after sending the command is not possible
    if ((! strncmp("MD", data, 2)) || (! strncmp("MS", data, 2)) ||
        (! strncmp("ME", data, 2))) {
      pimpl->laser_state_ = pImpl::LaserOn;
      pimpl->mx_capturing_ = true;
      pimpl->isPreCommand_QT_ = false;
    }
  }
  return pimpl->con_->send(data, size);
}


int ScipHandler::recv(char data[], int size, int timeout)
{
  return pimpl->con_->recv(data, size, timeout);
}


bool ScipHandler::loadParameter(RangeSensorParameter& parameters)
{
  return pimpl->loadParameter(parameters);
}


bool ScipHandler::versionLines(vector<string>& lines)
{
  int return_code = -1;
  char expected_response[] = { 0, -1 };
  if (! pimpl->response(return_code, "VV\r", expected_response, &lines)) {
    return false;
  }
  return true;
}


bool ScipHandler::setRawTimestampMode(bool on)
{
  char send_command[] = "TMx\r";
  send_command[2] = (on) ? '0' : '2';

  // Send TM0 of TM2
  int return_code = -1;
  char expected_response[] = { 0, -1 };
  if (! pimpl->response(return_code, send_command, expected_response)) {
    pimpl->error_message_ = (on) ? "TM0 fail." : "TM2 fail.";
    return false;
  }

  // If the response of TM1 and TM2 is normal, the laser is sure to have been turned off.
  pimpl->laser_state_ = pImpl::LaserOff;

  return true;
}


bool ScipHandler::rawTimestamp(int* timestamp)
{
  // Return TM1 value
  int return_code = -1;
  char expected_response[] = { 0, -1 };
  vector<string> lines;
  if (! pimpl->response(return_code, "TM1\r", expected_response, &lines)) {
    pimpl->error_message_ = "TM1 fail.";
    return false;
  }

  if ((lines.size() != 1) || (lines[0].size() != 5)) {
    pimpl->error_message_ = "response mismatch.";
    return false;
  }

  *timestamp = encode(lines[0].c_str(), 4);
  return true;
}


bool ScipHandler::setLaserOutput(bool on, bool force)
{
  return pimpl->setLaserOutput(on, force);
}


CaptureType ScipHandler::receiveCaptureData(vector<long>& data,
                                            long* timestamp, int* remain_times,
                                            int* total_times)
{
  return pimpl->receiveCaptureData(data, timestamp, remain_times, total_times);
}
