#ifndef URG_USB_COM_H
#define URG_USB_COM_H

/*!
  \file
  \brief Search for USB connected port

  \author Satofumi KAMIMURA

  $Id: UrgUsbCom.h 543 2009-02-03 23:18:10Z satofumi $
*/

#include "IsUsbCom.h"


namespace qrk
{
  /*!
    \brief Search for USB connected port
  */
  class UrgUsbCom : public IsUsbCom
  {
    UrgUsbCom(const UrgUsbCom& rhs);
    UrgUsbCom& operator = (const UrgUsbCom& rhs);

  public:
    UrgUsbCom(void);

    std::vector<std::string> setBaseNames(void);
    bool isUsbCom(const char* com_port);
  };
}

#endif /* !URG_USB_COM_H */
