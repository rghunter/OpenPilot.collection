/*!
  \file
  \brief Split function for string

  Without using boost \n  
  User can use boost::algorithm::split if boost library is permitted to use

  \author Satofumi KAMIMURA

  $Id: split.cpp 541 2009-02-03 02:28:38Z satofumi $
*/

#include "split.h"

using namespace std;


// Replacing delimiter with blank space and then divide
size_t qrk::split(vector<string>& tokens,
                  const string& line, const char* split_pattern,
                  bool continious_pattern)
{
  size_t next_first = 0;
  while (true) {

    size_t first_position = line.find_first_not_of(split_pattern, next_first);
    if (first_position == string::npos) {
      //Breaks if there is no token
      break;
    }

    if (! continious_pattern) {
      int n = static_cast<int>(first_position - next_first);
      // An empty token is added only by the separator.
      for (int i = 1; i < n; ++i) {
        tokens.push_back("");
      }
    }

    // Search for the end of token
    size_t last_position = line.find_first_of(split_pattern, first_position);
    size_t length = string::npos;
    if (last_position != string::npos) {
      length = last_position - first_position;
    }
    tokens.push_back(line.substr(first_position, length));

    if (next_first == string::npos) {
      //  Breaks because it seached upto last
      break;
    }

    next_first = last_position;
  }
  return tokens.size();
}
