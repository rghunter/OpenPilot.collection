#ifndef STRING_SPLIT_H
#define STRING_SPLIT_H

/*!
  \file
  \brief plit function for string

  \author Satofumi KAMIMURA

  $Id: split.h 439 2009-01-03 05:01:55Z satofumi $
*/

#include <vector>
#include <string>


namespace qrk
{
  /*!
    \brief Division by specified character

    \param[out] tokens Array of characters of division
    \param[in] original Array of characters to be divided
    \param[in] split_pattern �������s�������̗�
    \param[in] continious_pattern A consecutive separator is treated as one separator.

    \return Number of tokens after splitting
  */
  size_t split(std::vector<std::string>& tokens,
               const std::string& original, const char* split_pattern = " \t",
               bool continious_pattern = true);
}

#endif /* !STRING_SPLIT_H */
