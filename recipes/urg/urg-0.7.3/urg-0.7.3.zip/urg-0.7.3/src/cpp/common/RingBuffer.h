#ifndef RING_BUFFER_H
#define RING_BUFFER_H

/*!
  \file
  \brief Ring buffer

  \author Satofumi KAMIMURA

  $Id: RingBuffer.h 488 2009-01-21 03:33:51Z satofumi $
*/

#include <vector>
#include <cstring>


namespace qrk
{
  /*!
    \brief Ring buffer
  */
  template <class T>
  class RingBuffer
  {
    RingBuffer(const RingBuffer& rhs);
    RingBuffer& operator = (const RingBuffer& rhs);

    std::vector<T> ring_buffer_;
    size_t buffer_size_;
    size_t first_;
    size_t last_;


    size_t free_size(void)
    {
      return buffer_size_ -1 - size();
    }


    void extendBuffer(long additional_size)
    {
      size_t extend_size = (buffer_size_ == 0) ? 1 : buffer_size_;
      size_t pre_extend_size = extend_size;
      while (additional_size > 0) {
        if (extend_size <= 1) {
          extend_size = 2;
        } else {
          extend_size = static_cast<size_t>(extend_size * 1.5);
        }
        additional_size -= static_cast<int>(extend_size - pre_extend_size);
        pre_extend_size = extend_size;
      }
      ring_buffer_.resize(extend_size);

      // Data is moved according to the extending size. 
      if (first_ > last_) {
        size_t to_end = extend_size - buffer_size_;
        size_t move_size = (to_end > last_) ? last_ : to_end;
        // Data from 0 to "last" is moved to buffer starting from "buffer_size"
        memmove(&ring_buffer_[buffer_size_],
                &ring_buffer_[0], move_size * sizeof(T));

        // Data that cannot be moved is moved to 0th position
        size_t left_size = last_ - move_size;
        if (left_size == 0) {
          last_ += buffer_size_;
        } else {
          memmove(&ring_buffer_[0],
                  &ring_buffer_[move_size], left_size * sizeof(T));
          last_ = left_size;
        }
      }
      buffer_size_ = extend_size;
    }

  public:
    /*!
      \brief Contructor of buffer with initial size as specified

	  Buffer of size more than specified here can be maintained.
      
      \param[in] defaultSize buffer size
    */
    explicit RingBuffer(size_t defaultSize = 0)
      : buffer_size_(2), first_(0), last_(0)
    {
      while (buffer_size_ < defaultSize) {
        buffer_size_ = static_cast<size_t>(buffer_size_ * 1.5);
      }
      ring_buffer_.resize(buffer_size_);
    }


    /*!
      \brief Get buffer size
    */
    size_t size(void)
    {
      return (last_ >= first_) ?
        (last_ - first_) : (buffer_size_ - (first_ - last_));
    }


    /*!
      \brief Check whether buffer is empty or not

      \retval true No data
      \retval false Buffer is not empty.
    */
    bool empty(void)
    {
      return (first_ == last_) ? true : false;
    }


    /*!
      \brief Store data

      \param[in] data data
      \param[in] size size of data
    */
    void put(const T* data, size_t size)
    {
      long additional_size = static_cast<long>(size - free_size());
      if (additional_size > 0) {
        // If data size is more than buffer size, extend the buffer.
        extendBuffer(additional_size);
      }

      // Data arrangement
      if (first_ <= last_) {
        // Arrange from "last" to "buffer_size" terminal
        size_t to_end = buffer_size_ - last_;
        size_t move_size = (to_end > size) ? size : to_end;
        memmove(&ring_buffer_[last_], data, move_size * sizeof(T));
        last_ += move_size;
        last_ %= buffer_size_;

        long left_size = static_cast<long>(size - move_size);
        if (left_size > 0) {
          // Arrange from 0 to front of "first"
          memmove(&ring_buffer_[0], &data[move_size], left_size * sizeof(T));
          last_ = left_size;
        }
      } else {
        // Arrange from "last" to front of "first".
        memmove(&ring_buffer_[last_], data, size * sizeof(T));
        last_ += size;
      }
    }


    /*!
      \brief Get the data out.

      \param[out] data buffer to get out the data
      \param[in] size Maximum data size to be taken out 

      \return Size of data taken out
    */
    size_t get(T* data, size_t size)
    {
      // get data
      size_t return_size = (size <= this->size()) ? size : this->size();

      if (first_ <= last_) {
        memmove(data, &ring_buffer_[first_], return_size * sizeof(T));
        first_ += return_size;
      } else {
        //  Arrange from "first" to "buffer_size" terminal
        size_t to_end = buffer_size_ - first_;
        size_t move_size = (to_end > return_size) ? return_size : to_end;
        memmove(data, &ring_buffer_[first_], move_size * sizeof(T));
        first_ += move_size;
        first_ %= buffer_size_;

        long left_size = static_cast<long>(return_size - move_size);
        if (left_size > 0) {
          // Arrange from 0 to front of "last".
          memmove(&data[move_size], &ring_buffer_[0], left_size * sizeof(T));
          first_ = left_size;
        }
      }
      return return_size;
    }


    /*!
      \brief pushes a byte back onto the buffer

      \param[in] ch  pushed back byte
    */
    void ungetc(const char ch)
    {
      if (free_size() <= 0) {
        // If the range is insufficient, the size of the buffer is extended. 
        extendBuffer(1);
      }

      // Add character
      first_ = (first_ == 0) ? (buffer_size_ - 1) : (first_ - 1);
      ring_buffer_[first_] = ch;
    }


    /*!
      \brief Clear stored data
    */
    void clear(void)
    {
      first_ = 0;
      last_ = 0;
    }
  };
}

#endif /* !RING_BUFFER_H */
