/*!
  \file
  \brief ���W�n�̐���

  \author Satofumi KAMIMURA

  $Id: Coordinate.cpp 772 2009-05-05 06:57:57Z satofumi $

  �c���[�\���́A�o���������N�ŊǗ�����
*/

#include "Coordinate.h"
#include "Point.h"
#include "MathUtils.h"
#include <map>
#include <list>

using namespace qrk;
using namespace std;


namespace
{
  class RelativePosition
  {
  public:
    Coordinate* coordinate_;    //!< �Ǘ����W�n
    Position<long> offset_;      //!< �Ǘ����W�n�̌��_�ʒu
    bool on_module_;            //!< �Ǘ����W�n�����W���[����ɔz�u���Ă��邩


    RelativePosition(void) : coordinate_(NULL), on_module_(false)
    {
    }


    RelativePosition(Coordinate* parent, const Position<long>& offset,
                     bool on_module = false)
      : coordinate_(parent), offset_(offset), on_module_(on_module)
    {
    }
  };


  const bool OnModule = true;


  typedef map<const Coordinate*, RelativePosition> RelativeMap;
  typedef list<RelativePosition> RelativeList;
}


struct Coordinate::pImpl
{
  Coordinate* own_;
  Coordinate* parent_;
  RelativeMap children_;


  pImpl(Coordinate* own) : own_(own), parent_(NULL)
  {
  }


  void setParent(Coordinate* parent, const qrk::Position<long>& offset)
  {
    parent_ = parent;
    if (parent_) {
      parent_->pimpl->addChild(own_, offset);
    }
  }


  void addChild(Coordinate* child, const qrk::Position<long>& offset,
                bool on_module = false)
  {
    // !!! ������胋�[�g���̍��W�n�ɐڑ����Ȃ����߂̃��[�v�`�F�b�N��ǉ����ׂ�

    child->pimpl->parent_ = own_;
    RelativeMap::iterator p = children_.find(child);
    if (p == children_.end()) {
      // �V�K�o�^
      children_.insert(RelativeMap::value_type
                       (child, RelativePosition(child, offset, on_module)));

    } else {
      // �o�^���e���X�V
      children_[child] = RelativePosition(child, offset, on_module);
    }
  }


  const vector<Coordinate*> children(void)
  {
    // Coordinate �I�u�W�F�N�g������ vector ���쐬���ĕԂ�
    vector<Coordinate*> children_vector;
    for (RelativeMap::iterator it = children_.begin();
         it != children_.end(); ++it) {
      children_vector.push_back(it->second.coordinate_);
    }
    return children_vector;
  }


  qrk::Position<long> offset(const Coordinate* child) const
  {
    RelativeMap::const_iterator p = children_.find(child);
    if (p == children_.end()) {
      // �w����W�n���o�^����ĂȂ�
      Position<long> dummy;
      return dummy;
    }

    if (! p->second.on_module_) {
      return p->second.offset_;
    } else {
      // ���W���[���ʒu�𔽉f������
      Position<long> module_position = own_->position(parent_);
      Position<long> offset_position = p->second.offset_;
      updatePointPosition(offset_position, module_position);
      return offset_position;
    }
  }


  bool findToRoot(RelativeList& to_coordinate, const Coordinate* coordinate)
  {
    if (own_ == coordinate) {
      // �T���Ώ����������g�̏ꍇ�́A�����o�^�����ɕԂ�
      return true;
    }

    // ���[�g���֒T�����āA���W�n���X�g���쐬����
    const Coordinate* prev_p = own_;
    Coordinate* p = own_;
    for (; p != NULL; prev_p = p, p = p->pimpl->parent_) {
      to_coordinate.push_back(RelativePosition(p, p->offset(prev_p)));
      if (p == coordinate) {
        return true;
      }
    }

    if ((p == NULL) && (coordinate == NULL)) {
      // �����W�n�ƖڕW�̍��W�n�� NULL �̂Ƃ��́A�T���͐���
      return true;
    }

    to_coordinate.clear();
    return false;
  }


  void updatePointPosition(Position<long>& position,
                           const Position<long>& offset,
                           bool invert = false) const
  {

    // offset.angle �����Aposition �� x, y ����]�����A���ꂩ��A���s�ړ�
    if (! invert) {
      Point<long> move = rotate(position, -offset.to_rad());
      position.x = move.x + offset.x;
      position.y = move.y + offset.y;
      position.angle += offset.angle;

    } else {
      position.angle -= offset.angle;
      Point<long> move = rotate(offset, position.to_rad());
      position += Position<long>(move.x, move.y, deg(0));
    }
  }


  Point<long> rotate(const Position<long>& point, double radian) const
  {
    int x = static_cast<long>
      (ceil((point.x * cos(-radian)) - (point.y * sin(-radian))));
    int y = static_cast<long>
      (ceil((point.x * sin(-radian)) + (point.y * cos(-radian))));

    return Point<long>(x, y);
  }
};


Coordinate::Coordinate(void) : pimpl(new pImpl(this))
{
}


Coordinate::Coordinate(Coordinate* parent, const qrk::Position<long>& offset)
  : pimpl(new pImpl(this))
{
  pimpl->setParent(parent, offset);
}


Coordinate::~Coordinate(void)
{
}


void Coordinate::updatePointPosition(Position<long>& position,
                                     const Position<long>& offset,
                                     bool invert) const
{
  pimpl->updatePointPosition(position, offset, invert);
}


Coordinate* Coordinate::parent(void)
{
  return pimpl->parent_;
}


const vector<Coordinate*> Coordinate::children(void)
{
  return pimpl->children();
}


void Coordinate::addChild(Coordinate* child)
{
  pimpl->addChild(child, Position<long>(0, 0, deg(0)));
}


void Coordinate::addChild(Coordinate* child, const qrk::Position<long>& offset)
{
  pimpl->addChild(child, offset);
}


void Coordinate::addChildToModule(Coordinate* child)
{
  addChildToModule(child, Position<long>(0, 0, deg(0)));
}


void Coordinate::addChildToModule(Coordinate* child,
                                  const qrk::Position<long>& offset)
{
  pimpl->addChild(child, offset, OnModule);
}


qrk::Position<long> Coordinate::offset(const Coordinate* child) const
{
  return pimpl->offset(child);
}


qrk::Position<long> Coordinate::originPosition(Coordinate* coordinate)
{
  return pointPosition(coordinate, qrk::Position<long>(0, 0, deg(0)));
}


qrk::Position<long> Coordinate::pointPosition(Coordinate* coordinate,
                                             const qrk::Position<long>& position)
{
  // �w����W�n�܂ł̍��W�n���X�g���쐬����
  RelativeList to_target;
  if (pimpl->findToRoot(to_target, coordinate)) {

    Position<long> converted_position = position;
    for (RelativeList::iterator it = to_target.begin();
         it != to_target.end(); ++it) {
      pimpl->updatePointPosition(converted_position, it->offset_);
    }
    return converted_position;
  }

  if (coordinate->pimpl->findToRoot(to_target, this)) {

    Position<long> converted_position = position;
    for (RelativeList::reverse_iterator it = to_target.rbegin();
         it != to_target.rend(); ++it) {
      pimpl->updatePointPosition(converted_position, it->offset_, true);
    }
    return converted_position;
  }

  // ���t����Ȃ���΁A��O�𓊂���
  // !!! ���́A�܂������Ă��Ȃ�
  Position<long> dummy;
  return dummy;
}
