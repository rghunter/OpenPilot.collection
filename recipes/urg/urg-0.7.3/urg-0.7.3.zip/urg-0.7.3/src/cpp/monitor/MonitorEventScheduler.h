#ifndef MONITOR_EVENT_SCHEDULER_H
#define MONITOR_EVENT_SCHEDULER_H

/*!
  \file
  \brief ���j�^�C�x���g�Ǘ�

  \author Satofumi KAMIMURA

  $Id: MonitorEventScheduler.h 508 2009-01-23 05:29:45Z satofumi $
*/

#include <memory>


namespace qrk
{
  class ConditionVariable;
  class DeviceServer;
  class Lock;


  /*!
    \brief ���j�^�C�x���g�Ǘ�
  */
  class MonitorEventScheduler
  {
    MonitorEventScheduler(void);
    MonitorEventScheduler(const MonitorEventScheduler& rhs);
    MonitorEventScheduler& operator = (const MonitorEventScheduler& rhs);

    struct pImpl;
    std::auto_ptr<pImpl> pimpl;

  public:
    ~MonitorEventScheduler(void);
    static MonitorEventScheduler* object(void);

    void terminate(void);

    void registerWakeupTicks(ConditionVariable* condition, int ticks);
    void registerDeviceServer(DeviceServer* device);
  };
}

#endif /* !MONITOR_EVENT_SCHEDULER_H */
