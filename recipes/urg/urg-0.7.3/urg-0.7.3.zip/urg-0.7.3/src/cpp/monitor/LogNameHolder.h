#ifndef LOG_NAME_HOLDER_H
#define LOG_NAME_HOLDER_H

/*!
  \file
  \brief ���O���̊Ǘ�

  \author Satofumi KAMIMURA

  $Id: LogNameHolder.h 508 2009-01-23 05:29:45Z satofumi $
*/

#include <memory>
#include <string>


namespace qrk
{
  /*!
    \brief ���O���̊Ǘ�
  */
  class LogNameHolder
  {
    LogNameHolder(void);
    LogNameHolder(const LogNameHolder& rhs);
    LogNameHolder& operator = (const LogNameHolder& rhs);

    struct pImpl;
    const std::auto_ptr<pImpl> pimpl;

  public:
    ~LogNameHolder(void);
    static LogNameHolder* object(void);

    std::string name(const char* baseName);
  };
}

#endif /* !LOG_NAME_HOLDER_H */
