/*!
  \example scip_20_gd.cpp

  \brief Get data using GD command

  \author Satofumi KAMIMURA

  $Id: scip_20_gd.cpp 534 2009-02-01 15:48:15Z satofumi $
*/

#include "DetectOS.h"
#include "SerialCtrl.h"
#include "ConnectionUtils.h"
#include "ScipUtils.h"
#include <cstring>

using namespace qrk;


//! main
int main(int argc, char *argv[]) {

  // Change the port name appropriately.
#if defined(WINDOWS_OS)
  const char device[] = "COM3";
#elif defined(LINUX_OS)
  const char device[] = "/dev/ttyACM0";
#else
  const char device[] = "/dev/tty.usbmodem1d11";
#endif

  SerialCtrl con;
  if (! con.connect(device, 19200)) {
    printf("SerialCtrl::connect: %s\n", con.what());
    exit(1);
  }

  // Call SCIP2.0 and neglect the response.
  enum { Timeout = 200 };
  con.send("SCIP2.0\r", 8);
  skip(&con, Timeout);

  // Switch on URG's laser using BM command
  con.send("BM\r", 3);
  int ret = recvReply(&con, Timeout);
  if (ret < 0) {
    printf("BM fail: %d\n", ret);
    exit(1);
  }

  // Send GD command
  /*
    GD    or GS
    0000  should use AMIN value
    0768  should be less than AMAX
    01    �܂Ƃ߂鐔
    �܂Ƃ߂鐔�� X �ɂ���ƁA
    �A������ X �̋����f�[�^�̂����ŏ��̋����f�[�^���Ԃ����
    ��M�f�[�^�����������邱�Ƃ��ł���
  */
  con.send("GD0000076801\r", 13);

  // Display received data
  enum {
    LineMax = 64 + 1 + 1,
    URG_04LX_MAX = 768,
    PacketByte = 3,             // GD �Ȃ̂ŁA3byte
  };
  char buffer[LineMax];
  char data_buffer[(URG_04LX_MAX + 1) * PacketByte];
  int filled = 0;
  int line_count = 0;
  int n;
  while ((n = readline(&con, buffer, LineMax, Timeout)) > 0) {
    printf("%s\n", buffer);

    // Store data for decoding (All lines except first 3 are distance data)
    // line_count 0: Echo back
    //            1: Status
    //            2: Time stamp
    if (line_count >= 3) {
      int copy_size = n - 1;   // Last checksum is excluded.
      memmove(&data_buffer[filled], buffer, copy_size);
      filled += copy_size;
    }
    ++line_count;
  }
  printf("\n");

  // Decode the received data  
  // It is better to  decode line by line which results in good memory management. 
  for (int i = 0; i < URG_04LX_MAX; ++i) {
    // Caution: Valid distance data should be within [DMIN,DMAX].
    int length = decode(&data_buffer[i * PacketByte], PacketByte);
    printf("%d, ", length);
    if ((i % 10) == 00) {
      printf("\n");
    }
  }
  printf("\n");

  return 0;
}
