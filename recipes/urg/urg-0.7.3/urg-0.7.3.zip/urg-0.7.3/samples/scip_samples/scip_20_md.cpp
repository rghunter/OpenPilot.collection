/*!
  \example scip_20_md.cpp

  \brief Sample program : MD command

  \author Satofumi KAMIMURA

  $Id: scip_20_md.cpp 534 2009-02-01 15:48:15Z satofumi $
*/

#include "DetectOS.h"
#include "SerialCtrl.h"
#include "ConnectionUtils.h"
#include "ScipUtils.h"

using namespace qrk;


//! main
int main(int argc, char *argv[]) {

  // Change the port name appropriately.
#if defined(WINDOWS_OS)
  const char device[] = "COM3";
#elif defined(LINUX_OS)
  const char device[] = "/dev/ttyACM0";
#else
  const char device[] = "/dev/tty.usbmodem1d11";
#endif

  SerialCtrl con;
  if (! con.connect(device, 19200)) {
    printf("SerialCtrl::connect: %s\n", con.what());
    exit(1);
  }

  // Call Scip2.0 and neglect the response.
  enum { Timeout = 200 };
  con.send("SCIP2.0\r", 8);
  skip(&con, Timeout);

  // Send "MD" command
  /*
    MD    Or MS
    0000  should use AMIN value
    0768  should be less than AMAX
    01    �܂Ƃ߂鐔
    0     �t���[���Ԉ����BX ���w�肷��� X �������̃f�[�^�𑗂�Ȃ��Ȃ�
    02    �f�[�^�̑��M�񐔁B00 �w��Ŗ����Ƀf�[�^�𑗂葱����
  */
  con.send("MD0000076801000\r", 16);

  // Display received data
  // Actually, returned response will come into effect at the next cycle after the command is issued.
  // This is because, at first cycle, the laser will be in OFF state.

  enum {
    LineMax = 64 + 1 + 1,
    URG_04LX_MAX = 768,
    TryTimes = 5,
  };
  char buffer[LineMax];
  int n;
  for (int j = 0; j < TryTimes; ++j) { // Frequency at which data is read.
    while ((n = readline(&con, buffer, LineMax, Timeout)) > 0) {
      printf("%s\n", buffer);
    }
    printf("\n");

    // To get data of 2 scans, stop acquisition of data using "QT" command.
    if (j >= 1) {
      con.send("QT\r", 3);
    }
  }
  printf("\n");

  // Decoding of data is omitted.
  // After echo back and status, distance data follows continuously.
  // The other basic remains same as "GD" command response.

  return 0;
}
