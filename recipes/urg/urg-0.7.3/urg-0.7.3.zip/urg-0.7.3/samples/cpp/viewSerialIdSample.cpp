/*!
  \example viewSerialIdSample.cpp

  \brief �V���A�� ID �̎擾�T���v��

  \author Satofumi KAMIMURA

  $Id: viewSerialIdSample.cpp 508 2009-01-23 05:29:45Z satofumi $
*/

#include "UrgCtrl.h"
#include "UrgUtils.h"

using namespace qrk;


//! main
int main(int argc, char *argv[])
{
  UrgCtrl urg;
  if (! urg.connect("/dev/ttyACM0")) {
    printf("UrgCtrl::connect: %s\n", urg.what());
    exit(1);
  }

  printf("Serial ID: %ld\n", urgSerialId<UrgCtrl>(&urg));

  return 0;
}
