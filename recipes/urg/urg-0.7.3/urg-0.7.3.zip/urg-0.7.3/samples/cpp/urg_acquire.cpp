/*!
  \example urg_acquire.cpp

  \brief �w��񐔂̃f�[�^�擾���s���v���O����

  \author Satofumi KAMIMURA

  $Id: urg_acquire.cpp 547 2009-02-04 05:59:58Z satofumi $
*/

#include "UrgUsbCom.h"
#include "FindComPorts.h"
#include "UrgCtrl.h"
#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace qrk;
using namespace std;


namespace
{
  void outputCsv(ofstream& fout, const vector<long>& data)
  {
    for (vector<long>::const_iterator it = data.begin();
         it != data.end(); ++it) {
      // urg_minDistance() �ȉ��̋����f�[�^�́A�����l��\��
      fout << *it << ',';
    }
    fout << endl;
  }
}


//! main
int main(int argc, char *argv[])
{
  if (argc < 3) {
    cerr << "usage:" << endl
         << "\t" << argv[0] << " <number of scans> <output file>\n"
         << endl;
    exit(1);
  }
  int scan_times = atoi(argv[1]);
  max(scan_times, 0);
  ofstream fout(argv[2]);
  if (! fout.is_open()) {
    perror(argv[2]);
  }

  // URG �|�[�g�̒T��
  UrgUsbCom urg_usb;
  FindComPorts urg_finder(&urg_usb);
  vector<string> ports = urg_finder.find();

  if (ports.empty()) {
    cerr << "no ports." << endl;
    exit(1);
  }

  UrgCtrl urg;
  if (! urg.connect(ports[0].c_str())) {
    cerr << "UrgCtrl::connect: " << urg.what() << endl;
    exit(1);
  }

  // �w�肳�ꂽ�񐔂��� GD �X�L�������s��
  vector<long> data;
  for (int i = 0; i < scan_times; ++i) {
    int n = urg.capture(data);
    if (n < 0) {
      continue;
    }
    outputCsv(fout, data);
    cout << (i + 1) << " scaned." << endl;
  }

  return 0;
}
