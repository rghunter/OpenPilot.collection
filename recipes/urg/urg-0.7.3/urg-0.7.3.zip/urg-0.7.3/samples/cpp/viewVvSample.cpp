/*!
  \example viewVvSample.cpp

  \brief Displays VV command data 

  \author Satofumi KAMIMURA

  $Id: viewVvSample.cpp 529 2009-01-30 13:32:22Z satofumi $
*/

#include "UrgCtrl.h"
#include <cstdlib>
#include <iostream>

using namespace qrk;
using namespace std;


//! main
int main(int argc, char *argv[])
{
  //const char device[] = "COM3";
  const char device[] = "/dev/ttyACM0";

  UrgCtrl urg;
  if (! urg.connect(device)) {
    printf("UrgCtrl::connect: %s\n", urg.what());
    exit(1);
  }

  vector<string> lines;

  // Receive version information
  urg.versionLines(lines);
  if (lines.empty()) {
    cerr << "UrgCtrl::versionLines: " << urg.what() << endl;
    exit(1);
  }

  // Output
  for (vector<string>::iterator it = lines.begin();
       it != lines.end(); ++it) {
    cout << *it << endl;
  }

  return 0;
}
