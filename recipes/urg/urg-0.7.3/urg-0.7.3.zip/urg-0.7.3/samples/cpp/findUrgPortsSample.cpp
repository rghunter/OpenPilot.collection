/*!
  \example findUrgPortsSample.cpp

  \brief FindUrgPorts �̓���T���v��

  \author Satofumi KAMIMURA

  $Id: findUrgPortsSample.cpp 610 2009-02-22 09:00:37Z satofumi $
*/

#include "UrgUsbCom.h"
#include "FindComPorts.h"
#include <SDL.h>

using namespace qrk;
using namespace std;


//! main
int main(int argc, char *argv[]) {

  UrgUsbCom urg_usb;
  FindComPorts urg_finder(&urg_usb);
  vector<string> ports = urg_finder.find();

  // ���t�������|�[�g��S�ďo�͂���
  printf("ports: %u\n", ports.size());
  for (vector<string>::iterator it = ports.begin();
       it != ports.end(); ++it) {
    printf("%s\n", it->c_str());
  }

  return 0;
}
