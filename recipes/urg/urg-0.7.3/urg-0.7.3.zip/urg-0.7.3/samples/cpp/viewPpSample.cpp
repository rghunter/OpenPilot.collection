/*!
  \example viewPpSample.cpp

  \brief Displays PP data

  \author Satofumi KAMIMURA

  $Id: viewPpSample.cpp 508 2009-01-23 05:29:45Z satofumi $
*/

#include "UrgCtrl.h"
#include "RangeSensorParameter.h"
#include <cstdlib>

using namespace qrk;


//! main
int main(int argc, char *argv[])
{
  //const char device[] = "COM3";
  const char device[] = "/dev/ttyACM0";

  UrgCtrl urg;
  if (! urg.connect(device)) {
    printf("UrgCtrl::connect: %s\n", urg.what());
    exit(1);
  }

  // Outputs parameter information
  RangeSensorParameter parameters = urg.parameter();
  printf("model: %s\n", parameters.model.c_str());
  printf("distance_min: %ld\n", parameters.distance_min);
  printf("distance_max: %ld\n", parameters.distance_max);
  printf("area_total: %d\n", parameters.area_total);
  printf("area_min: %d\n", parameters.area_min);
  printf("area_max: %d\n", parameters.area_max);
  printf("area_front: %d\n", parameters.area_front);
  printf("scan_rpm: %d\n", parameters.scan_rpm);

  return 0;
}
